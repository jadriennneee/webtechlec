The resource folder contains the following files and directory:
		> img directory - this contains all of the images and 
						  icons used for the website
		> HTML Documents that composes the website content 
			- index.html contains the home pag
			- overview.html contains the content for the topic 'Overview 
			  of the World Wide Web'
			- httpTechnical.html and httpfundamentals.html contains the	
			  content for the topic HTTP
			- htmldoc.html contains the content for the topic HTML
			- uri.html contains the content for the topic URI
		> style.css - contains the stylesheet used in styling the website
		> script.js - contains the script used to enable certain functionalities
					  of the website
					  
HOW TO ACCESS THE WEBSITE RESOURCES:
	1. To access the resources, first install or open your server such as WAMP for
	   Windows users and MAMP for MacOS Users
	2. After activating the server as mentioned above, click the WAMP/MAMP icon then
	   under 'Your VirtualHosts', click 'VirtualHost Management' then it will open up
	   a browser which will prompt you to enter the name for your virtual host,In this 
	   case, we used the name 'webtech' then indicate the absolute path to the location
	   where the resource is located.
	3. After creating the virtualhost for the website, restart al of the services.
	4. After the services has restarted, click the WAMP/MAMP server icon once again and
	   under the 'Your VirtualHosts', click 'VirtualHost Management', click the virtualname
	   of the website. This opens a browser and displays the website.